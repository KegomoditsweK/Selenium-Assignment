package com.Selenium;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Admin_Tab extends Config{

	@Test(priority = 1)
	public void admintap() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.linkText("Admin")).click();
	}

	// validate url for admin

	@Test(priority = 2)
	public void Validate_adminUrl() {

		test = extent.createTest("Validate admin tap URL", "url should contain admin/viewSystemUsers");

		if (driver.getCurrentUrl().contains("admin/viewSystemUsers")){

			testResult = true;
			output = "url contains admin/viewSystemUsers";  
		}
		else {
			testResult = false;
			output = "url does not contain admin/viewSystemUsers"; 
		}
		assertTrue(testResult);
		test.pass(output);
	}	

	// validate add button 

	@Test(priority = 3)
	public void validateAdd () { 
		test = extent.createTest("Add button should be displayed", "Validate that add button is displayed");

		WebElement add = driver.findElement(By.name("btnAdd")); 

		if(add.isDisplayed()) {

			test.pass("Add button is displayed");
		}
	} 

	// validate Delete button
	@Test (priority = 4)
	public void validateDelete() { 
		test = extent.createTest("Delete button should be displayed", "Validate that delete button is displayed"); 

		WebElement delete = driver.findElement(By.id("btnDelete")); 
		if(delete.isDisplayed()) {

			test.pass("Delete button is displayed");
		}
	} 

	// validate search button
	@Test(priority = 5)
	public void validateSearch() {
		test = extent.createTest("Search button should be displayed", "Validate that search button is displayed"); 

		WebElement search = driver.findElement(By.id("searchBtn")); 

		if(search.isDisplayed()) {
			test.pass("Search button is displayed");
		}
	} 

	// validate Reset button
	@Test(priority = 6)
	public void validateReset() { 
		test = extent.createTest("Reset button should be displayed", "Validate that reset button is displayed"); 

		WebElement reset = driver.findElement(By.id("resetBtn")); 

		if(reset.isDisplayed()) {
			test.pass("Reset button is displayed");
		}
	}


}


