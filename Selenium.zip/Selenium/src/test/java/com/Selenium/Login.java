package com.Selenium;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;


public class Login extends Config {
	
	//automate testcases
	@Test(priority = 1)
	public void login() {

		driver.findElement(By.id(Locators.username)).clear();
		driver.findElement(By.id(Locators.username)).sendKeys(Variables.username);
		driver.findElement(By.id(Locators.password)).clear();
		driver.findElement(By.id(Locators.password)).sendKeys(Variables.password);
		driver.findElement(By.id("btnLogin")).click();

	}
   //check if url contains dashboard
	@Test(priority = 2)
	public void Valid_url() {

		test = extent.createTest("Validate URL", "checking the presence of keyword Dashboard in the URL");
		if (driver.getCurrentUrl().contains("dashboard")){

			testResult = true;
			output = "url contains dashboard";  
		}
		else {
			testResult = false;
			output = "url does not contain dashboard"; 
		}
		assertTrue(testResult);
		test.pass(output);  
	}

	@Test(priority = 3)

	public void check_admin() {
		test = extent.createTest("check admin tap", "checking the presence of admin tap");

		//calling WebElement by linkText
		WebElement admin_tab = driver.findElement(By.linkText("Admin"));

		//checking if the admin tab is displayed 
		if(admin_tab.isDisplayed()) {
			test.pass("Admin tab is displayed");
			logger.info("Test Passed. admin tab is available");
		}
	}

	@Test(priority = 4)

	public void check_welcome() {

		test = extent.createTest("Welcome Admin should display at right panel", "Validate that welcome Admin should display at right panel");

		//calling WebElement by linkText
		WebElement welcome_admin = driver.findElement(By.id("welcome"));

		//checking if the "Welcome Admin Tab" is displayed at right panel 
		if(welcome_admin.isDisplayed()) {
			test.pass("Welcome Admin is displayed");
			logger.info("Test Passed");
		}
	}
}