package com.Selenium;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class Enter_Information extends Config{
		  @Test(priority = 1)
		  public void enter_info() throws InterruptedException {
			  
			  	  
			  Select role = new Select(driver.findElement(By.name(Locators.role)));
				role.selectByVisibleText(Variables.role);
			  driver.findElement(By.name(Locators.emp_name)).clear();
			  driver.findElement(By.name(Locators.emp_name)).sendKeys(Variables.emp_name); 
			  
			  driver.findElement(By.name(Locators.emp_username)).clear();
			  driver.findElement(By.name(Locators.emp_username)).sendKeys(Variables.emp_username);
			  
			  Select status = new Select(driver.findElement(By.name(Locators.status)));
				status.selectByVisibleText(Variables.status);
			  
				
			  
			  driver.findElement(By.name(Locators.password)).clear();
			  driver.findElement(By.name(Locators.password)).sendKeys(Variables.password);
			  
			  driver.findElement(By.name(Locators.emp_re_password)).clear();
			  driver.findElement(By.name(Locators.emp_re_password)).sendKeys(Variables.emp_re_password);
			  
			  Thread.sleep(2000);
			  WebElement save = driver.findElement(By.name("btnSave"));
			  save.click();	  
		  }
		  
		  @Test(priority = 2)
		  public void validate_status() {
			  
			  test = extent.createTest("Validate dropdown status", "Verify Status dropdown is Selected to enable.");
				 
			  Select status = new Select(driver.findElement(By.name(Locators.status)));
				if (status.getFirstSelectedOption().getText().equalsIgnoreCase("Enabled")) {

					testResult = true;
					output = "status dropdown is selected to enabled";  
				}
				else {
					testResult = false;
					output = "status dropdown is not selected to enabled"; 
				}
				assertTrue(testResult);
				test.pass(output);
			 
		  }

}