package com.Selenium;

public class Locators {
	
	static String username = "txtUsername";
    static String password = "txtPassword";
    static String role = "systemUser[userType]";
    static String emp_name = "systemUser[employeeName][empName]";
    static String emp_username = "systemUser[userName]";
    static String status = "systemUser[status]";
    static String emp_password = "systemUser[password]";
    static String emp_re_password = "systemUser[confirmPassword]";

}
