package com.Selenium;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Search_Result extends Config {

	@Test

	public void search_deleted() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.name("searchSystemUser[userName]")).clear();
		driver.findElement(By.name("searchSystemUser[userName]")).sendKeys(Variables.emp_username);

		driver.findElement(By.id("searchBtn")).click();
	}
}



