package com.Selenium;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Click_Add extends Config {
	 @Test(priority = 12)
	  public void clickadd() throws InterruptedException {
		 Thread.sleep(3000);
		 driver.findElement(By.name("btnAdd")).click(); 
	 }
	 
	 @Test(priority = 1)
	 
	 public void validate_addbtnUrl() {
		 
		 test = extent.createTest("Validate add button URL", "url should contain saveSystemUser");
		 
			if (driver.getCurrentUrl().contains("saveSystemUser")){

				testResult = true;
				output = "url contains saveSystemUser";  
			}
			else {
				testResult = false;
				output = "url does not contain saveSystemUser"; 
			}
			assertTrue(testResult);
			test.pass(output);
	 }
	 
	 @Test(priority = 2)
		public void validateAdd () { 
			test = extent.createTest("Validate Add User H1", "Add User H1 should display ");
			
			WebElement add_user = driver.findElement(By.id("UserHeading")); 
			
			if(add_user.isDisplayed()) {
				
				test.pass("Add User is displayed");
			}
		} 		 
}
