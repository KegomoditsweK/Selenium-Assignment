package com.Selenium;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Logout extends Config{


	@Test(priority = 1)

	public void logout() throws InterruptedException {

		driver.findElement(By.id("welcome")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Logout")).click();
	}

	@Test(priority = 2)

	public void validate_url_landingPage() {

		test = extent.createTest("Validate URL(login) for landing page", "Validate URL for landing page");

		if (driver.getCurrentUrl().contains("login")){

			testResult = true;
			output = "url contains login";  
		}
		else {
			testResult = false;
			output = "url does not contain login"; 
		}
		assertTrue(testResult);
		test.pass(output);
	}

	@Test(priority = 3)

	public void validate_url_landingPage2() {

		test = extent.createTest("Validate URL(OrangeHRM) for landing page", "Validate URL for landing page");

		if (driver.getCurrentUrl().contains("OrangeHRM")){

			testResult = true;
			output = "url contains OrangeHRM";  
		}
		else {
			testResult = false;
			output = "url does not contain OrangeHRM"; 
		}
		assertTrue(testResult);
		test.pass(output);
	}

}