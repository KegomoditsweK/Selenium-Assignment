package com.Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Delete_Users extends Config{
	
	
	
	@Test

	public void delete_record() throws InterruptedException {
		
		
		WebElement check_box = driver.findElement(By.xpath("//*[@id=\"ohrmList_chkSelectAll\"]"));
		Thread.sleep(2000);
		  check_box.click();
		  
		  driver.findElement(By.id("btnDelete")).click();
		  Thread.sleep(3000);
		  driver.findElement(By.id("dialogDeleteBtn")).click();
		  
		 //Seacrhing again
		  Thread.sleep(2000);
			driver.findElement(By.name("searchSystemUser[userName]")).clear();
			driver.findElement(By.name("searchSystemUser[userName]")).sendKeys(Variables.emp_username);

			driver.findElement(By.id("searchBtn")).click();
		  
		  
	}

}