package com.Selenium;

public class Variables {	
		
		static String username = "Admin";
		static String password = "admin123";
		static String role = "Admin";
		static String emp_name = "Jasmine Morgan";
		static String emp_username = "Selenium52";
		static String status = "Enabled";
		static String emp_password = "Selenium500";
		static String emp_re_password = "Selenium500";

}
