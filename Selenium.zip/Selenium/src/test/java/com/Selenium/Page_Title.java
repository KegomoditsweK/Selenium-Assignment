package com.Selenium;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class Page_Title extends Config {

	@Test

	public void first_test() {

		test = extent.createTest("Open orangeHRM URL", " get the title of the current page.");

		//URL to the website
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");
		String actualTitle = driver.getTitle();
		String expectedTitle = "OrangeHRM";

		Assert.assertEquals(actualTitle, expectedTitle);

		test.pass("Test Passed");
	}

	@AfterMethod
	public void EvaluateResult(ITestResult Results) {

		if(Results.getStatus() == ITestResult.FAILURE) {
			test.fail("Test Failed");
			logger.info("Test Failed");
		}

	}



}
